"""
客户端 CODEX · 授权与计量服务（第二期）
接口分四类：
  1) 客户端认证：登录 / 心跳 / 登出 / 查自己
  2) 授权规则：一码一机 + 换机间隔 + 到期锁 + 额度锁
  3) 后台管理：客户 / 发码 / 入账 / 停用 / 看用量（需要一个管理令牌）
  4) 计量与更新：每次调用记账 / 版本查询

启动：uvicorn app:app --host 0.0.0.0 --port 8000
"""
import os
import time
from datetime import datetime, timezone, timedelta

from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

import db
import metering
from licensing import make_code, verify_code, make_token, verify_token

ADMIN_TOKEN = os.environ.get("ADMIN_TOKEN", "change-me-admin")
DEFAULT_SWITCH_MINUTES = int(os.environ.get("DEFAULT_SWITCH_MINUTES", "30"))

app = FastAPI(title="Codex License API", version="1.0.0.949")

# 【签发器支持】允许本机签发工具（file:// 或本地 http 页面）跨域调用后台接口。
# 管理接口本身仍受 x-admin-token 保护，未放宽鉴权。
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------- 请求体模型 ----------------

class LoginIn(BaseModel):
    code: str
    machine_fp: str = Field(min_length=4)
    customer_name: str = ""                  # 【V1.0.0.912 用户要求】客户端上报的客户名称 → 后台自动同步
    phone: str = ""                          # 【V1.0.0.912 用户要求】客户端上报的手机号码 → 后台自动同步


class VerifyIn(BaseModel):
    """客户端登录窗（POST /api/verify）的请求体；字段名与客户端保持一致。"""
    code: str
    device: str = ""                         # 客户端设备标识（等价于 machine_fp）
    machine_fp: str = ""
    refCode: str = ""                        # 预留：推荐码
    customerName: str = ""                   # 客户名称（后台自动同步）
    phone: str = ""                          # 手机号码（后台自动同步）


class TokenIn(BaseModel):
    token: str
    machine_fp: str = Field(min_length=4)


class PrecheckIn(BaseModel):
    license_id: int
    estimated_tokens: int = 0                 # 本次请求预估消耗，0 表示只查余额


class ChargeIn(BaseModel):
    license_id: int
    request_id: str
    model: str = ""
    input_tokens: int = 0
    output_tokens: int = 0
    cached_tokens: int = 0
    success: bool = True


class CustomerIn(BaseModel):
    name: str
    contact: str = ""
    note: str = ""


class IssueIn(BaseModel):
    customer_id: int | None = None  # 【V1.0.0.945】可省略：不填则自动建「待绑定」客户，客户首次登录时再绑定名称与手机号
    mode: str = "token"                      # token / month / year / forever
    days: int = 0                            # month/year 用天数换算；0 表示永久
    projects: list[str] = []
    switch_minutes: int = 0                  # 0 表示用默认值
    max_switches: int = 0                    # 0 表示不限
    note: str = ""


class TopupIn(BaseModel):
    license_id: int | None = None            # 兼容旧写法：直接给数字 ID
    code: str = ""                           # 推荐写法：直接给授权码（入账跟随授权码）
    tokens: int
    note: str = ""


class IdIn(BaseModel):
    id: int                                  # 通用「按主键删除」入参


class StatusIn(BaseModel):
    license_id: int
    status: str                              # active / suspended


# ---------------- 小工具 ----------------

def now_iso():
    return datetime.now(timezone.utc).isoformat()


def require_admin(token: str | None):
    if not token or token != ADMIN_TOKEN:
        raise HTTPException(status_code=401, detail="管理令牌不正确")


def get_license(license_id: int):
    row = db.query("SELECT * FROM licenses WHERE id=%s", (license_id,), one=True)
    if not row:
        raise HTTPException(status_code=404, detail="授权不存在")
    return row


def projects_of(license_id: int):
    rows = db.query(
        """SELECT p.code, p.name FROM license_projects lp
           JOIN projects p ON p.id = lp.project_id
           WHERE lp.license_id=%s AND p.enabled=true
           ORDER BY p.sort_order""",
        (license_id,),
    )
    return [{"code": r["code"], "name": r["name"]} for r in rows]


def check_time_lock(row) -> None:
    exp = row.get("expires_at")
    if exp and exp.timestamp() < time.time():
        db.execute("UPDATE licenses SET status='expired', updated_at=now() WHERE id=%s", (row["id"],))
        raise HTTPException(status_code=403, detail="授权已到期，请联系服务方续期")


def check_balance_lock(license_id: int) -> int:
    bal = metering.get_balance(license_id)
    if bal <= 0:
        raise HTTPException(status_code=402, detail="额度已用完，请续费后再使用")
    return bal


# ---------------- 1) 客户端认证 ----------------

@app.get("/healthz")
def healthz():
    row = db.query("SELECT 1 AS ok", one=True)
    return {"ok": bool(row and row["ok"] == 1), "server_time": now_iso()}


def _precheck_customer_name(license_row, name: str) -> None:
    """【V1.0.0.945 用户要求】客户名称规则：
    ① 系统默认查重——名称已被任何一张客户档案占用，就不允许再绑定（不能注册）；
    ② 名称一旦绑定即「终生锁定」，之后登录填别的名称一律拒绝（手机号可以换，名称不能换）。
    只做校验、不改任何数据；不通过直接抛 HTTPException，由 /api/verify 透传给客户端。"""
    nm = (name or "").strip()[:60]
    if not nm:
        return
    cid = license_row.get("customer_id")
    if not cid:
        return
    cur = db.query("SELECT coalesce(name,'') AS name FROM customers WHERE id=%s", (cid,), one=True) or {}
    old = str(cur.get("name") or "").strip()
    if old:
        if old != nm:
            raise HTTPException(
                status_code=403,
                detail="该授权码的客户名称已绑定为「" + old + "」，终生不可更换（手机号可以更换）",
            )
        return
    dup = db.query(
        "SELECT id, coalesce(name,'') AS name FROM customers WHERE lower(name)=lower(%s) AND id<>%s LIMIT 1",
        (nm, cid), one=True,
    )
    if dup:
        raise HTTPException(
            status_code=409,
            detail="客户名称「" + nm + "」已被占用，请换一个名称",
        )


def _sync_customer_from_client(license_row, name: str, phone: str) -> dict:
    """【V1.0.0.912 用户要求】把客户端填写的「客户名称 / 手机号码」同步进客户档案。
    后台「客户与授权（同一界面）」表里的客户名与联系方式，读的就是这里。"""
    nm = (name or "").strip()[:60]
    ph = (phone or "").strip()[:40]
    cid = license_row.get("customer_id")
    if not cid or (not nm and not ph):
        return {}
    # 【V1.0.0.945】名称查重 + 终生锁定（手机号可随时更新）
    _precheck_customer_name(license_row, nm)
    sets, args = [], []
    if nm:
        sets.append("name=%s")
        args.append(nm)
    if ph:
        sets.append("contact=%s")
        args.append(ph)
    args.append(cid)
    db.execute(
        "UPDATE customers SET " + ", ".join(sets) + ", updated_at=now() WHERE id=%s",
        tuple(args),
    )
    return {"customer_id": cid, "customer_name": nm, "contact": ph}


@app.post("/api/auth/login")
def login(req: LoginIn):
    row = db.query("SELECT * FROM licenses WHERE code=%s", (req.code.strip(),), one=True)
    if not row:
        payload = verify_code(req.code.strip())
        if not payload:
            raise HTTPException(status_code=404, detail="授权码无效")
        raise HTTPException(status_code=404, detail="授权码未在服务器登记，请联系服务方")

    if row["status"] != "active":
        raise HTTPException(status_code=403, detail=f"授权状态异常：{row['status']}")

    check_time_lock(row)
    # 【V1.0.0.957 用户要求】登录门禁不再卡额度：0 余额也放行登录，
    # 让客户能完成「授权码 + 客户名称 + 手机号」的首次绑定；
    # 额度只在真正调用模型时（/api/meter/precheck、/api/meter/charge）才校验。
    # 原实现：balance = check_balance_lock(row["id"]) —— 0 余额直接抛 402，
    # 客户连「名称 + 手机号」都绑不上，界面只显示「验证失败」，误导性极强。
    try:
        balance = metering.get_balance(row["id"])
    except Exception:
        balance = 0
    # 【V1.0.0.945】先校验客户名称（查重 + 终生锁定），不合规直接拒绝，
    # 避免名称不合法却已经把换机/会话等绑定状态改掉。
    _precheck_customer_name(row, getattr(req, "customer_name", ""))

    fp = req.machine_fp.strip()
    switch_minutes = int(row["switch_minutes"] or DEFAULT_SWITCH_MINUTES)
    bound = row.get("machine_fp")
    switched = False

    if bound and bound != fp:
        other = db.query(
            """SELECT machine_fp, last_seen,
                      EXTRACT(EPOCH FROM (now()-last_seen))::int AS elapsed
               FROM sessions WHERE license_id=%s AND machine_fp<>%s
               ORDER BY last_seen DESC LIMIT 1""",
            (row["id"], fp), one=True,
        )
        if other:
            elapsed = int(other["elapsed"])
            if elapsed < switch_minutes * 60:
                wait_min = max(1, (switch_minutes * 60 - elapsed + 59) // 60)
                raise HTTPException(
                    status_code=409,
                    detail=f"该授权码正在另一台电脑上使用，请等待 {wait_min} 分钟后再试",
                )
        if row["max_switches"] and int(row["switch_count"] or 0) >= int(row["max_switches"]):
            raise HTTPException(status_code=403, detail="换机次数已达上限，请联系服务方")

        db.execute(
            "UPDATE machine_bindings SET released_at=now() WHERE license_id=%s AND released_at IS NULL",
            (row["id"],),
        )
        db.execute(
            """INSERT INTO machine_bindings(license_id, machine_fp, note)
               VALUES(%s,%s,'自助换机')""",
            (row["id"], fp),
        )
        db.execute(
            """UPDATE licenses SET machine_fp=%s, switch_count=switch_count+1, updated_at=now()
               WHERE id=%s""",
            (fp, row["id"]),
        )
        switched = True
    elif not bound:
        db.execute(
            "UPDATE licenses SET machine_fp=%s, updated_at=now() WHERE id=%s",
            (fp, row["id"]),
        )
        db.execute(
            """INSERT INTO machine_bindings(license_id, machine_fp, note)
               VALUES(%s,%s,'首次绑定')""",
            (row["id"], fp),
        )

    db.execute(
        """INSERT INTO sessions(license_id, machine_fp, opened_at, last_seen)
           VALUES(%s,%s,now(),now())
           ON CONFLICT (license_id, machine_fp)
           DO UPDATE SET last_seen=now()""",
        (row["id"], fp),
    )

    # 【V1.0.0.912 用户要求】客户端上报的客户名称 / 手机号码 → 同步进客户档案（后台自动显示）
    _sync = _sync_customer_from_client(row, getattr(req, "customer_name", ""), getattr(req, "phone", ""))

    token = make_token(row["id"], fp)
    return {
        "ok": True,
        "token": token,
        "license_id": row["id"],
        "billing_mode": row["billing_mode"],
        "expires_at": row["expires_at"].isoformat() if row.get("expires_at") else None,
        "balance": balance,
        "projects": projects_of(row["id"]),
        "switch_minutes": switch_minutes,
        "switched": switched,
        "customer_name": _sync.get("customer_name", ""),
        "contact": _sync.get("contact", ""),
        "server_time": now_iso(),
    }


@app.post("/api/verify")
def verify_client(req: VerifyIn):
    """【V1.0.0.912 用户要求】客户端登录窗激活接口（POST /api/verify）。
    客户端填的「客户名称 / 手机号码」→ 自动写进该授权对应的客户档案，
    后台「客户与授权」表里的客户名与联系方式立刻同步显示。"""
    fp = (req.machine_fp or req.device or "").strip()
    if len(fp) < 4:
        fp = "CLIENT-UNKNOWN"
    try:
        r = login(LoginIn(code=(req.code or "").strip(), machine_fp=fp,
                          customer_name=req.customerName, phone=req.phone))
    except HTTPException as e:
        return {"ok": False, "reason": str(e.detail)}
    exp_ms = 0
    if r.get("expires_at"):
        try:
            exp_ms = int(datetime.fromisoformat(
                str(r["expires_at"]).replace("Z", "+00:00")).timestamp() * 1000)
        except Exception:
            exp_ms = 0
    plan_cn = {"token": "按 TOKEN 额度", "month": "按月", "year": "按年", "forever": "永久"}.get(
        str(r.get("billing_mode") or ""), str(r.get("billing_mode") or ""))
    return {
        "ok": True,
        "token": r.get("balance"),
        "balance": r.get("balance"),
        "plan": plan_cn,
        "expireAt": exp_ms,
        "verifyDays": 7,
        "license_id": r.get("license_id"),
        "customer_name": r.get("customer_name", ""),
        "contact": r.get("contact", ""),
    }


class NameCheckIn(BaseModel):
    """客户端输入客户名称时的实时查重请求"""
    name: str = ""
    code: str = ""


@app.post("/api/check-name")
def check_name(req: NameCheckIn):
    """【V1.0.0.945 用户要求】系统默认查重：客户在登录面板输入名称时同步检查，
    名称已被占用则返回 taken=true（客户端立即提示换一个）。"""
    nm = (req.name or "").strip()[:60]
    if not nm:
        return {"ok": False, "taken": False, "reason": "请输入客户名称"}
    dup = db.query(
        "SELECT id FROM customers WHERE lower(name)=lower(%s) LIMIT 1", (nm,), one=True,
    )
    if dup:
        return {"ok": False, "taken": True, "reason": "该名称已被使用，请换一个名称"}
    return {"ok": True, "taken": False, "reason": ""}


class ResolveIn(BaseModel):
    code: str = ""


@app.post("/api/resolve-code")
def resolve_code(req: ResolveIn, x_resolve_token: str | None = Header(default=None)):
    """【V1.0.0.949 用户要求】「KEY 绑定在授权码中」的落地接口。
    本机中转站拿客户填写的授权码来这里换取 license_id，
    客户因此无需再单独输入任何中转 Key。
    只接受携带正确令牌的调用（令牌即管理口令；两个服务同机部署）。"""
    if x_resolve_token != ADMIN_TOKEN:
        raise HTTPException(status_code=401, detail="resolve_token_invalid")
    row = db.query(
        "SELECT id, status FROM licenses WHERE code=%s", (req.code.strip(),), one=True,
    )
    if not row:
        return {"ok": False, "license_id": 0, "reason": "not_found"}
    if row["status"] != "active":
        return {"ok": False, "license_id": 0, "reason": row["status"]}
    return {"ok": True, "license_id": int(row["id"]), "reason": ""}


@app.post("/api/auth/heartbeat")
def heartbeat(req: TokenIn):
    info = verify_token(req.token)
    if not info:
        raise HTTPException(status_code=401, detail="登录状态已失效，请重新登录")
    if info["machine_fp"] != req.machine_fp:
        raise HTTPException(status_code=409, detail="设备不一致，请重新登录")
    db.execute(
        "UPDATE sessions SET last_seen=now() WHERE license_id=%s AND machine_fp=%s",
        (info["license_id"], req.machine_fp),
    )
    return {"ok": True, "balance": metering.get_balance(info["license_id"]), "server_time": now_iso()}


@app.post("/api/auth/logout")
def logout(req: TokenIn):
    info = verify_token(req.token)
    if not info:
        return {"ok": True}
    db.execute(
        "UPDATE sessions SET last_seen=now() WHERE license_id=%s AND machine_fp=%s",
        (info["license_id"], req.machine_fp),
    )
    return {"ok": True, "note": "已登出；换机需按间隔规则等待"}


@app.post("/api/auth/me")
def me(req: TokenIn):
    info = verify_token(req.token)
    if not info:
        raise HTTPException(status_code=401, detail="登录状态已失效，请重新登录")
    row = get_license(info["license_id"])
    return {
        "license_id": row["id"],
        "billing_mode": row["billing_mode"],
        "expires_at": row["expires_at"].isoformat() if row.get("expires_at") else None,
        "balance": metering.get_balance(row["id"]),
        "projects": projects_of(row["id"]),
        "machine_fp": row.get("machine_fp"),
        "status": row["status"],
    }


# ---------------- 3) 后台管理 ----------------

@app.post("/api/admin/customers")
def create_customer(body: CustomerIn, x_admin_token: str = Header(default="")):
    require_admin(x_admin_token)
    row = db.execute(
        "INSERT INTO customers(name,contact,note) VALUES(%s,%s,%s) RETURNING id",
        (body.name, body.contact, body.note), fetch="one",
    )
    return {"ok": True, "customer_id": row["id"]}


@app.get("/api/admin/customers")
def list_customers(x_admin_token: str = Header(default="")):
    require_admin(x_admin_token)
    return {"items": db.query("SELECT * FROM customers ORDER BY id DESC")}


@app.get("/api/admin/projects")
def list_projects(x_admin_token: str = Header(default="")):
    require_admin(x_admin_token)
    return {"items": db.query("SELECT id, code, name, enabled FROM projects ORDER BY sort_order, id")}


@app.post("/api/admin/licenses")
def issue_license(body: IssueIn, x_admin_token: str = Header(default="")):
    require_admin(x_admin_token)
    # 【V1.0.0.945】客户资料可完全省略：不填 customer_id 时自动建一张「待绑定」客户档案，
    # 客户首次登录填了名称/手机号后，由 _sync_customer_from_client 自动绑定上去。
    cid = body.customer_id
    if not cid:
        _c = db.execute(
            "INSERT INTO customers(name, contact, note) VALUES('','',%s) RETURNING id",
            ("由授权码自动创建（客户首次登录时绑定名称与手机号）",), fetch="one",
        )
        cid = _c["id"]
    cust = db.query("SELECT * FROM customers WHERE id=%s", (cid,), one=True)
    if not cust:
        raise HTTPException(status_code=404, detail="客户不存在")

    exp_ts = None
    if body.days and body.days > 0:
        exp_ts = int(time.time()) + body.days * 86400

    code = make_code(cid, body.mode, exp_ts, body.projects, body.note)
    sw = body.switch_minutes or DEFAULT_SWITCH_MINUTES

    row = db.execute(
        """INSERT INTO licenses(customer_id, code, billing_mode, expires_at, switch_minutes, max_switches)
           VALUES(%s,%s,%s,%s,%s,%s) RETURNING id""",
        (cid, code, body.mode,
         datetime.fromtimestamp(exp_ts, tz=timezone.utc) if exp_ts else None,
         sw, body.max_switches or None),
        fetch="one",
    )
    lic_id = row["id"]
    for pc in body.projects:
        db.execute(
            """INSERT INTO license_projects(license_id, project_id)
               SELECT %s, id FROM projects WHERE code=%s
               ON CONFLICT DO NOTHING""",
            (lic_id, pc),
        )
    return {
        "ok": True,
        "license_id": lic_id,
        "code": code,
        "expires_at": datetime.fromtimestamp(exp_ts, tz=timezone.utc).isoformat() if exp_ts else None,
        "switch_minutes": sw,
        "projects": body.projects,
    }


@app.get("/api/admin/licenses")
def list_licenses(x_admin_token: str = Header(default="")):
    require_admin(x_admin_token)
    rows = db.query(
        """SELECT l.id, l.customer_id, c.name AS customer, l.code, l.billing_mode, l.expires_at, l.status,
                  l.machine_fp, l.switch_count, l.switch_minutes, l.max_switches,
                  COALESCE((SELECT SUM(change_tokens) FROM balance_ledger b WHERE b.license_id=l.id),0)::bigint AS balance
           FROM licenses l JOIN customers c ON c.id=l.customer_id
           ORDER BY l.id DESC"""
    )
    for _r in rows:
        _r["projects"] = [p["code"] for p in projects_of(_r["id"])]
        # 发码时填的「备注」是随授权码一起签名进 payload 的（库里没有单独字段），
        # 这里把码解回来，让备注能在后台表格里直接显示。
        _p = verify_code(_r.get("code") or "")
        _r["note"] = (_p or {}).get("note") or ""
    return {"items": rows}


def resolve_license_id(code_or_id: str | None, license_id: int | None = None) -> int:
    """把「授权码」或「授权ID」统一解析成真实 license_id。
    纯数字 → 当授权ID；其它 → 当授权码去库里反查。查不到就 404。"""
    raw = (code_or_id or "").strip()
    if raw:
        if raw.isdigit():
            lid = int(raw)
        else:
            row = db.query("SELECT id FROM licenses WHERE code=%s", (raw,), one=True)
            if not row:
                raise HTTPException(status_code=404, detail="没找到这个授权码对应的授权")
            lid = row["id"]
    else:
        lid = license_id
    if lid is None:
        raise HTTPException(status_code=400, detail="请填写授权码")
    return lid


def resolve_usage_license_id(code: str = "", license_id: str = "") -> int:
    """用量查询用：授权码或授权ID 都接受；格式不对就给一句人话，不再抛 422。"""
    raw = (code or license_id or "").strip()
    if not raw:
        raise HTTPException(status_code=400, detail="请先填写授权码（或授权ID）再查询")
    if raw.isdigit():
        return int(raw)
    if raw.startswith("CX1.") or len(raw) >= 20:
        return resolve_license_id(raw, None)
    raise HTTPException(status_code=400, detail="格式不对：授权ID 是纯数字；授权码是 CX1. 开头的一长串")


@app.post("/api/admin/topup")
def admin_topup(body: TopupIn, x_admin_token: str = Header(default="")):
    require_admin(x_admin_token)
    lid = resolve_license_id(body.code, body.license_id)
    get_license(lid)
    return {"ok": True, "license_id": lid, **metering.topup(lid, body.tokens, "admin", body.note)}


@app.post("/api/admin/status")
def admin_status(body: StatusIn, x_admin_token: str = Header(default="")):
    require_admin(x_admin_token)
    if body.status not in ("active", "suspended"):
        raise HTTPException(status_code=400, detail="状态只能是 active 或 suspended")
    db.execute("UPDATE licenses SET status=%s, updated_at=now() WHERE id=%s", (body.status, body.license_id))
    return {"ok": True, "license_id": body.license_id, "status": body.status}


class LicenseUpdateIn(BaseModel):
    license_id: int
    billing_mode: str | None = None          # token / month / year / forever
    days: int | None = None                  # 不传=不改到期；0=不过期；>0=从现在起算天数
    switch_minutes: int | None = None        # 换机最短间隔（分钟）
    max_switches: int | None = None          # 累计换机次数上限；0 表示不限
    status: str | None = None                # active / suspended
    projects: list[str] | None = None        # 不传=不改项目权限


@app.post("/api/admin/license/update")
def admin_update_license(body: LicenseUpdateIn, x_admin_token: str = Header(default="")):
    require_admin(x_admin_token)
    get_license(body.license_id)
    fields, params = [], []
    if body.billing_mode is not None:
        if body.billing_mode not in ("token", "month", "year", "forever"):
            raise HTTPException(status_code=400, detail="计费方式只能是 token / month / year / forever")
        fields.append("billing_mode=%s"); params.append(body.billing_mode)
    if body.days is not None:
        if body.days < 0:
            raise HTTPException(status_code=400, detail="有效天数不能为负数")
        if body.days == 0:
            fields.append("expires_at=NULL")
        else:
            fields.append("expires_at=%s")
            params.append(datetime.now(timezone.utc) + timedelta(days=body.days))
    if body.switch_minutes is not None:
        fields.append("switch_minutes=%s"); params.append(max(0, body.switch_minutes))
    if body.max_switches is not None:
        fields.append("max_switches=%s"); params.append(None if body.max_switches <= 0 else body.max_switches)
    if body.status is not None:
        if body.status not in ("active", "suspended"):
            raise HTTPException(status_code=400, detail="状态只能是 active / suspended")
        fields.append("status=%s"); params.append(body.status)
    if not fields and body.projects is None:
        raise HTTPException(status_code=400, detail="没有需要修改的内容")
    if fields:
        fields.append("updated_at=now()")
        params.append(body.license_id)
        db.execute("UPDATE licenses SET " + ", ".join(fields) + " WHERE id=%s", tuple(params))
    if body.projects is not None:
        db.execute("DELETE FROM license_projects WHERE license_id=%s", (body.license_id,))
        for pc in body.projects:
            db.execute(
                """INSERT INTO license_projects(license_id, project_id)
                   SELECT %s, id FROM projects WHERE code=%s
                   ON CONFLICT DO NOTHING""",
                (body.license_id, pc),
            )
    row = get_license(body.license_id)
    return {
        "ok": True,
        "license_id": body.license_id,
        "billing_mode": row.get("billing_mode"),
        "expires_at": row.get("expires_at").isoformat() if row.get("expires_at") else None,
        "switch_minutes": row.get("switch_minutes"),
        "max_switches": row.get("max_switches"),
        "status": row.get("status"),
        "projects": [p["code"] for p in projects_of(body.license_id)],
    }


@app.post("/api/admin/license/delete")
def admin_delete_license(body: IdIn, x_admin_token: str = Header(default="")):
    """删除一个授权（连同其项目权限/绑定/会话/账本/流水，由外键级联清理）"""
    require_admin(x_admin_token)
    row = get_license(body.id)
    db.execute("DELETE FROM licenses WHERE id=%s", (body.id,))
    return {"ok": True, "license_id": body.id, "code": row.get("code")}


@app.post("/api/admin/customer/delete")
def admin_delete_customer(body: IdIn, x_admin_token: str = Header(default="")):
    """删除一个客户；名下若还有授权则拒绝，避免误删导致授权悬空"""
    require_admin(x_admin_token)
    cust = db.query("SELECT * FROM customers WHERE id=%s", (body.id,), one=True)
    if not cust:
        raise HTTPException(status_code=404, detail="客户不存在")
    cnt = db.query("SELECT COUNT(*)::int AS n FROM licenses WHERE customer_id=%s", (body.id,), one=True)
    n = int((cnt or {}).get("n") or 0)
    if n > 0:
        raise HTTPException(status_code=409, detail=f"该客户名下还有 {n} 个授权，请先删除这些授权")
    db.execute("DELETE FROM customers WHERE id=%s", (body.id,))
    return {"ok": True, "customer_id": body.id, "name": cust.get("name")}


@app.get("/api/admin/usage")
def admin_usage(code: str = "", license_id: str = "", limit: int = 50, x_admin_token: str = Header(default="")):
    require_admin(x_admin_token)
    lid = resolve_usage_license_id(code, license_id)
    rows = db.query(
        """SELECT request_id, model, input_tokens, output_tokens, cached_tokens,
                  charged_tokens, balance_after, success, created_at
           FROM token_usage WHERE license_id=%s ORDER BY id DESC LIMIT %s""",
        (lid, limit),
    )
    return {"items": rows, "license_id": lid, "balance": metering.get_balance(lid)}


# ---------------- 4) 计量与更新 ----------------

@app.post("/api/meter/precheck")
def meter_precheck(body: PrecheckIn):
    """请求前置检查：额度不足直接拒绝，避免把余额透支成负数"""
    row = get_license(body.license_id)
    if row["status"] != "active":
        raise HTTPException(status_code=403, detail=f"授权状态异常：{row['status']}")
    check_time_lock(row)
    bal = metering.get_balance(body.license_id)
    if bal <= 0:
        raise HTTPException(status_code=402, detail="额度已用完，请续费后再使用")
    if body.estimated_tokens and bal < body.estimated_tokens:
        raise HTTPException(
            status_code=402,
            detail=f"剩余额度不足以完成本次请求（剩余 {bal}，预估需要 {body.estimated_tokens}）",
        )
    return {"ok": True, "balance": bal}


@app.post("/api/meter/charge")
def meter_charge(body: ChargeIn):
    get_license(body.license_id)
    return {"ok": True, **metering.charge(
        body.license_id, body.request_id, body.model,
        body.input_tokens, body.output_tokens, body.cached_tokens, body.success,
    )}


@app.get("/api/version/latest")
def version_latest(channel: str = "stable", platform: str = "win-x64"):
    row = db.query(
        """SELECT version, url, sha256, size_bytes, is_force, notes, created_at
           FROM releases WHERE channel=%s AND platform=%s AND revoked=false
           ORDER BY created_at DESC LIMIT 1""",
        (channel, platform), one=True,
    )
    if not row:
        return {"has_update": False}
    return {
        "has_update": True,
        "version": row["version"],
        "url": row["url"],
        "sha256": row["sha256"],
        "size_bytes": row["size_bytes"],
        "force": row["is_force"],
        "notes": row["notes"],
        "published_at": row["created_at"].isoformat(),
    }


# ---------------- 管理后台页面 ----------------

STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")


@app.get("/admin")
def admin_page():
    """你用浏览器打开 /admin 就能发码、看用量"""
    # 明确禁用缓存：避免浏览器一直吃旧的页面（表现为标签页图标不更新）
    return FileResponse(
        os.path.join(STATIC_DIR, "admin.html"),
        headers={
            "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
            "Pragma": "no-cache",
            "Expires": "0",
        },
    )


# 标签页图标（favicon）：与 CODEX 客户端保持同一套图标
def _static_file(name: str, media_type: str):
    path = os.path.join(STATIC_DIR, name)
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="图标文件不存在")
    return FileResponse(path, media_type=media_type)


@app.get("/favicon.ico", include_in_schema=False)
def favicon_ico():
    return _static_file("favicon.ico", "image/x-icon")


@app.get("/favicon.png", include_in_schema=False)
def favicon_png():
    return _static_file("favicon.png", "image/png")


@app.get("/favicon-32.png", include_in_schema=False)
def favicon_32_png():
    return _static_file("favicon-32.png", "image/png")
