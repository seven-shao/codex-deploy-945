# -*- coding: utf-8 -*-
"""【V1.0.0.957】给服务器上的中转站 relay.py 打补丁：
   ① _key_rows 返回 enabled 字段
   ② check_access 拦截被停用的 Key
   ③ 新增 /admin/keys/set 接口（按字段局部更新：名称/配额/绑定授权/上游Key/停用）
用法：python3 _relay_patch.py [apply]
不带 apply 只做 dry-run（校验锚点命中数，不改文件）。
"""
import sys, os, shutil, time

F = os.environ.get('RELAY_PY', '/opt/ai-relay/relay.py')
if not os.path.exists(F):
    print('FILE_NOT_FOUND: ' + F); sys.exit(1)
s = open(F, encoding='utf-8').read()
print('TARGET=' + F + '  BYTES=' + str(len(s.encode('utf-8'))))

P = []
def add(name, old, new):
    P.append((name, old, new))

# ---------- P1: _key_rows 增加 enabled ----------
o1 = '"lastAt": (usage.get(k) or {}).get("lastAt") or 0,'
n1 = (o1 + '\n'
      '            # 【V1.0.0.957】被后台「停用」的 Key 标记（缺省视为启用）\n'
      '            "enabled": (rec.get("enabled") is not False),')
add('P1 _key_rows加enabled', o1, n1)

# ---------- P2: check_access 拦截停用 ----------
o2 = ('        if not key or key not in allow:\n'
      '            raise HTTPException(status_code=401, detail="client_key_not_allowed")')
n2 = (o2 + '\n'
      '        # 【V1.0.0.957】被停用的 Key：立刻拒绝（后台「停用」按钮写的就是这个字段）\n'
      '        if (clients.get(key) or {}).get("enabled") is False:\n'
      '            raise HTTPException(status_code=403, detail="key_disabled")')
add('P2 check_access拦停用', o2, n2)

# ---------- P3: 新增 /admin/keys/set ----------
o3 = '@app.post("/admin/keys/del")'
n3 = '''@app.post("/admin/keys/set")
def admin_keys_set(payload: dict, request: Request):
    """【V1.0.0.957】按字段局部更新某个 Key（名称/配额/绑定授权/上游Key/停用）。
    与 /admin/keys/add 的区别：只改传进来的字段，没传的一律不动
    （add 是整体覆盖，会把没传的 name/licenseId/quotaTokens 清空，不能拿来做编辑）。"""
    cfg = load_cfg()
    _admin_guard(cfg, request)
    key = str(payload.get("key") or "").strip()
    if not key:
        raise HTTPException(status_code=400, detail="缺少 key")
    clients = cfg.setdefault("clients", {})
    if not isinstance(clients, dict):
        raise HTTPException(status_code=500, detail="relay_config_broken")
    if key not in clients:
        raise HTTPException(status_code=404, detail="key_not_found")
    cur = clients.get(key)
    rec = dict(cur) if isinstance(cur, dict) else {}
    if "name" in payload:
        rec["name"] = str(payload.get("name") or "").strip() or "未命名"
    if "upstreamKey" in payload:
        rec["upstreamKey"] = str(payload.get("upstreamKey") or "").strip()
    if "licenseId" in payload:
        try:
            rec["licenseId"] = int(payload.get("licenseId") or 0)
        except Exception:
            rec["licenseId"] = 0
    if "quotaTokens" in payload:
        try:
            rec["quotaTokens"] = int(payload.get("quotaTokens") or 0)
        except Exception:
            rec["quotaTokens"] = 0
    if "note" in payload:
        rec["note"] = str(payload.get("note") or "")
    if "enabled" in payload:
        rec["enabled"] = bool(payload.get("enabled"))
    clients[key] = rec
    save_cfg(cfg)
    return {"ok": True, "key": key, "enabled": rec.get("enabled") is not False}


@app.post("/admin/keys/del")'''
add('P3 新增/admin/keys/set', o3, n3)

# ---------- 校验 ----------
ok = True
for name, old, new in P:
    c = s.count(old)
    flag = 'OK   ' if c == 1 else 'FAIL '
    print(flag + name + '  count=' + str(c))
    if c != 1:
        ok = False

if not ok:
    print('ABORT: 有锚点命中数不为 1，未做任何修改')
    sys.exit(1)

if len(sys.argv) > 1 and sys.argv[1] == 'apply':
    bak = F + '.bak-957-' + time.strftime('%Y%m%d%H%M%S')
    shutil.copy(F, bak)
    for name, old, new in P:
        s = s.replace(old, new)
    open(F, 'w', encoding='utf-8').write(s)
    print('APPLIED  backup=' + bak + '  new_bytes=' + str(len(s.encode('utf-8'))))
else:
    print('DRY-RUN OK: 3 处补丁全部命中，加 apply 参数才真写')
